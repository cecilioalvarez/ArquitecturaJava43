package com.arquitecturajava.repositorios;

import com.arquitecturajava.bo.Comentario;

public interface ComentarioRepository  extends GenericRepository<Comentario,Integer>{

	
	
	
}
